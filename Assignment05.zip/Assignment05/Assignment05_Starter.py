# ------------------------------------------------------------------------ #
# Title: Assignment 05
# Description: Working with Dictionaries and Files
#              When the program starts, load each "row" of data
#              in "ToDoToDoList.txt" into a python Dictionary.
#              Add the each dictionary "row" to a python list "table"
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created started script
# <Michael Hause>,<8/10/2021>,Added code to complete assignment 5
# ------------------------------------------------------------------------ #

# -- Data -- #
# declare variables and constants
strFile = "ToDoList.txt"   # An object that represents a file
strData = ""  # A row of text data from the file
dicRow = {}    # A row of data separated into elements of a dictionary {Task,Priority}
lstTable = []  # A list that acts as a 'table' of rows
strMenu = ""   # A menu of user options
strChoice = "" # A Capture the user option selection
objFile = None

# -- Processing -- #
# Step 1 - When the program starts, load the any data you have
# in a text file called ToDoList.txt into a python list of dictionaries rows (like Lab 5-2)
objFile = open(strFile, "r")   #opens text file
for row in objFile:
    lstRow = row.split(",") #adds text entries to a list
    dicRow = {"task": lstRow[0], "priority": lstRow[1].strip()} #adds list entries to a dictionary
    lstTable.append(dicRow) #appends rows into a table of values
objFile.close() #closes text file

# -- Input/Output -- #
# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()  # adding a new line for looks
    # Step 3 - Show the current items in the table
    if (strChoice.strip() == '1'):
        print("Current ToDo list: ")
        for objRow in lstTable:
            print(objRow["task"] + "," + objRow["priority"].strip()) #displays each entry in the table separated by a comma
        continue
    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        print("Please enter a task and give it a priority")
        strTask = str(input("Task: "))   #input for the task
        strPriority = str(input("Priority: ")) #input for the priority
        dicRow = {"task":strTask, "priority":strPriority} #adds those inputs to a dictionary row
        lstTable.append(dicRow)  #appends rows to the table
        print("Your items have been successfully added!")
        continue
    # Step 5 - Remove a new item from the list/Table
    elif (strChoice.strip() == '3'):
        for objRow in lstTable:
            print(objRow["task"] + "," + objRow["priority"].strip()) #displays current entries in the table
        strRemove = input("Please select the task you would like to remove: ") #input string to be removed
        for objRow in lstTable:
            if strRemove.lower() in objRow["task"]:
                lstTable.remove(objRow)    #goes through each line in the table and removes the row that contains user input string
                print("The item has been successfully removed")
                break
            else:
                print("Item not found")
        continue
    # Step 6 - Save tasks to the ToDoToDoList.txt file
    elif (strChoice.strip() == '4'):
        objFile = open(strFile, "w")
        for objRow in lstTable:
            objFile.write(objRow["task"] + "," + objRow["priority"] + "\n") #writes rows in table into the text file
        objFile.close()
        print("Your data has been saved successfully!")
        continue
    # Step 7 - Exit program
    elif (strChoice.strip() == '5'):
        strEnd = input(" Are you sure you want to exit? (y or n): ")
        if (strEnd.lower() == 'y'):   #user input variable to ensure they actually want to close the program
           print("Thank you!")
           break
        elif (strEnd.lower() == 'n'):  #goes back to the menu if the user did not want to exit
            continue
        else:
            print("Please select y or n")
            continue
 # and Exit the program

